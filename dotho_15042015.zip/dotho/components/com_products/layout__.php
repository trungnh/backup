<script type="text/javascript" src="js/cloud-zoom.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo THIS_TEM_PATH; ?>css/cloud-zoom.css">
<div class="wrapper">
    <div class="page">
        <div class="main-container col1-layout">
            <div class="main">
                <div style="overflow: visible;" class="col-main">
                                        
<div id="messages_product_view"></div>
<script gapi_processed="true" type="text/javascript" src="may_files/plusone.js"></script>
<script type="text/javascript">
    jQuery(function(){
        var messages = new String('');
        var addToCartAction =  new String ('0');
        if (messages.length >0){
            if(addToCartAction == 1){
                showMessagesAddtoCart(jQuery('#messages_popup'));
            }else{
                showMessagesNoHeader(jQuery('#messages_popup'),5000);
            }
        }
        //like facebook
//        var ulrLikeFace = "http://www.facebook.com/plugins/like.php?locale=vi&amp;href=http://nhanh.vn/may-lam-banh-ngo-nghinh-hinh-thu.html&amp;layout=standard&amp;show_faces=false&amp;width=260&amp;action=like&amp;font=arial&amp;colorscheme=white&amp;height=25";
//        jQuery(".facebook-box").html('<iframe name="ffb" scrolling="no" frameborder="0" allowtransparency="true" style="border:none; overflow:hidden; width:450px; height:25px;" src="'+ulrLikeFace+'" ></iframe>');

    });

    jQuery(window).load(function(){
        //like facebook
        var ulrLikeBox = "http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2Fmuanhanh&amp;send=false&amp;layout=button_count&amp;width=120&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=21&amp;appId=259613557393120";
        jQuery(".facebook-box").html('<iframe src="'+ulrLikeBox+'" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:120px; height:21px;" allowTransparency="true"></iframe>');
    });
           
</script>
<div class="product-view">
    <div class="product-essential">
        <form action="http://nhanh.vn/checkout/cart/add/uenc/aHR0cDovL25oYW5oLnZuL21heS1sYW0tYmFuaC1uZ28tbmdoaW5oLWhpbmgtdGh1Lmh0bWw,/product/4010/" method="post" id="product_addtocart_form">
                <div class="no-display">
                    <input name="product" value="4010" id="current-product" type="hidden">
                    <input name="related_product" id="related-products-field" value="" type="hidden">
                    <input name="only_add_related" value="0" id="only-add-related" type="hidden">
                </div>

                <div style="width: 659px;" class="product-shop">
                    <!--addToBox add to cart-->
                    <div id="addtoCart-wrapper">
                    <div id="product-shop-view-addtoCart">
                        <div class="add-to-box">
                        <div class="add-to-cart">
            <div id="qty">
                    <p class="label"><span> <label for="qty">Số lượng:</label></span></p>
            <div id="qty-input-div">
                <select name="qty" class="input-text" id="qty_input">
                                                                            <option selected="selected" value="1" title="Số lượng">1</option>
                                                                            <option value="2" title="Số lượng">2</option>
                                                                            <option value="3" title="Số lượng">3</option>
                                                                            <option value="4" title="Số lượng">4</option>
                                                                            <option value="5" title="Số lượng">5</option>
                                                                            <option value="6" title="Số lượng">6</option>
                                                                            <option value="7" title="Số lượng">7</option>
                                                                            <option value="8" title="Số lượng">8</option>
                                                                            <option value="9" title="Số lượng">9</option>
                                                                            <option value="10" title="Số lượng">10</option>
                                                                            <option value="11" title="Số lượng">11</option>
                                                                            <option value="12" title="Số lượng">12</option>
                                                                            <option value="13" title="Số lượng">13</option>
                                                                            <option value="14" title="Số lượng">14</option>
                                                                            <option value="15" title="Số lượng">15</option>
                                                                            <option value="16" title="Số lượng">16</option>
                                                                            <option value="17" title="Số lượng">17</option>
                                                                            <option value="18" title="Số lượng">18</option>
                                                                            <option value="19" title="Số lượng">19</option>
                                                                            <option value="20" title="Số lượng">20</option>
                                                                            <option value="21" title="Số lượng">21</option>
                                                                            <option value="22" title="Số lượng">22</option>
                                                                            <option value="23" title="Số lượng">23</option>
                                                                            <option value="24" title="Số lượng">24</option>
                                                                            <option value="25" title="Số lượng">25</option>
                                                                            <option value="26" title="Số lượng">26</option>
                                                                            <option value="27" title="Số lượng">27</option>
                                                                            <option value="28" title="Số lượng">28</option>
                                                                            <option value="29" title="Số lượng">29</option>
                                                                            <option value="30" title="Số lượng">30</option>
                                                                            <option value="31" title="Số lượng">31</option>
                                                                            <option value="32" title="Số lượng">32</option>
                                                                            <option value="33" title="Số lượng">33</option>
                                                                            <option value="34" title="Số lượng">34</option>
                                                                            <option value="35" title="Số lượng">35</option>
                                                                            <option value="36" title="Số lượng">36</option>
                                                                            <option value="37" title="Số lượng">37</option>
                                                                            <option value="38" title="Số lượng">38</option>
                                                                            <option value="39" title="Số lượng">39</option>
                                                                            <option value="40" title="Số lượng">40</option>
                                                                            <option value="41" title="Số lượng">41</option>
                                                                            <option value="42" title="Số lượng">42</option>
                                                                            <option value="43" title="Số lượng">43</option>
                                                                            <option value="44" title="Số lượng">44</option>
                                                                            <option value="45" title="Số lượng">45</option>
                                                                            <option value="46" title="Số lượng">46</option>
                                                                            <option value="47" title="Số lượng">47</option>
                                                                            <option value="48" title="Số lượng">48</option>
                                                                            <option value="49" title="Số lượng">49</option>
                                                                            <option value="50" title="Số lượng">50</option>
                                                                            <option value="51" title="Số lượng">51</option>
                                                                            <option value="52" title="Số lượng">52</option>
                                                                            <option value="53" title="Số lượng">53</option>
                                                                            <option value="54" title="Số lượng">54</option>
                                                                            <option value="55" title="Số lượng">55</option>
                                                                            <option value="56" title="Số lượng">56</option>
                                                                            <option value="57" title="Số lượng">57</option>
                                                                            <option value="58" title="Số lượng">58</option>
                                                                            <option value="59" title="Số lượng">59</option>
                                                                            <option value="60" title="Số lượng">60</option>
                                                                            <option value="61" title="Số lượng">61</option>
                                                                            <option value="62" title="Số lượng">62</option>
                                                                            <option value="63" title="Số lượng">63</option>
                                                                            <option value="64" title="Số lượng">64</option>
                                                                            <option value="65" title="Số lượng">65</option>
                                                                            <option value="66" title="Số lượng">66</option>
                                                                            <option value="67" title="Số lượng">67</option>
                                                                            <option value="68" title="Số lượng">68</option>
                                                                            <option value="69" title="Số lượng">69</option>
                                                                            <option value="70" title="Số lượng">70</option>
                                                                            <option value="71" title="Số lượng">71</option>
                                                                            <option value="72" title="Số lượng">72</option>
                                                                            <option value="73" title="Số lượng">73</option>
                                                                            <option value="74" title="Số lượng">74</option>
                                                                            <option value="75" title="Số lượng">75</option>
                                                                            <option value="76" title="Số lượng">76</option>
                                                                            <option value="77" title="Số lượng">77</option>
                                                                            <option value="78" title="Số lượng">78</option>
                                                                            <option value="79" title="Số lượng">79</option>
                                                                            <option value="80" title="Số lượng">80</option>
                                                                            <option value="81" title="Số lượng">81</option>
                                                                            <option value="82" title="Số lượng">82</option>
                                                                            <option value="83" title="Số lượng">83</option>
                                                                            <option value="84" title="Số lượng">84</option>
                                                                            <option value="85" title="Số lượng">85</option>
                                                                            <option value="86" title="Số lượng">86</option>
                                                                            <option value="87" title="Số lượng">87</option>
                                                                            <option value="88" title="Số lượng">88</option>
                                                                            <option value="89" title="Số lượng">89</option>
                                                                            <option value="90" title="Số lượng">90</option>
                                                                            <option value="91" title="Số lượng">91</option>
                                                                            <option value="92" title="Số lượng">92</option>
                                                                            <option value="93" title="Số lượng">93</option>
                                                                            <option value="94" title="Số lượng">94</option>
                                                                            <option value="95" title="Số lượng">95</option>
                                                                            <option value="96" title="Số lượng">96</option>
                                                                            <option value="97" title="Số lượng">97</option>
                                                                            <option value="98" title="Số lượng">98</option>
                                                                            <option value="99" title="Số lượng">99</option>
                                                                            <option value="100" title="Số lượng">100</option>
                                                    </select>
                </div>
                                </div>

    
                                    <div class="link-add-cart" id="Buynow">
                                    <a title="Click mua ngay" onclick="onlyCurrentProduct();buyNow();productAddToCartForm.submit(this)"><span>Mua ngay</span> </a>
                                    <input name="is_buy_now" value="0" type="hidden">
                                    <input name="return_url" value="" type="hidden">
                                </div>
                                <p class="label" id="label-or"><span class="or">Hoặc</span></p>
                                <div class="link-add-cart " id="add-to-cart">
                                    <input name="ajax" value="1" type="hidden">
                                    <input name="return_url" value="http://nhanh.vn/may-lam-banh-ngo-nghinh-hinh-thu.html" type="hidden">
                                    <a title="Cho vào giỏ hàng" onclick="onlyCurrentProduct();productAddToCartForm.submit(this)"><span>Cho vào giỏ hàng</span></a>
                                    
                                </div>
                                     <div style="margin:0 auto 15px;">
                                    <span style="font-size:11px;color:#990000;">Chỉ bán tại:</span> <a href="http://nhanh.vn/shop/hcm/" style="color: rgb(153, 0, 0); font-weight: bold;">Hồ Chí Minh</a>
                                </div>
                                            <div class="link-login-register">
        <a href="http://nhanh.vn/customer/account/login/referer/aHR0cDovL25oYW5oLnZuL2NhdGFsb2cvcHJvZHVjdC92aWV3L2lkLzEwMzcv/">Đăng nhập</a> hoặc <a href="http://nhanh.vn/dang-ky-thanh-vien.html">Đăng ký</a> để mua hàng thuận tiện và nhiều ưu đãi hơn                                    </div>
    
                                    </div>
                                    <script type="text/javascript">
                                        function buyNow(){
                                            jQuery('input[name=return_url]').val('http://nhanh.vn/checkout/onepage/');
                                            jQuery('input[name=is_buy_now]').val('1');
                                        }
                                        function onlyCurrentProduct(){
                                            $('related-products-field').value='';
                                        }

                                    </script>
                        </div>
                    </div>
                                                 </div>
                    <!--EndaddToBox add to cart-->
                    <div style="width: 425px;" id="product-shop-view-content">
                        <div class="product-name">
                            <h1>
                                Máy làm bánh ngộ nghĩnh hình thú                             </h1>
                        </div>
                        <div class="rating-compare">
                        <div class="ratings">
    <p class="no-rating"><a href="http://nhanh.vn/review/product/list/id/1037/#review-form">Hãy là người đầu tiên nhận xét sản phẩm này</a></p>
  </div>                        

<div class="add-compare-wishlist">
    <span class="separator">|</span>
    <p><a href="http://nhanh.vn/wishlist/index/add/product/1037/" onclick="productAddToCartForm.submitLight(this, 'http://nhanh.vn/wishlist/index/add/product/1037/'); return false;" class="link-wishlist">Lưu lại</a></p>
    
    <p><span class="separator">|</span> <a href="http://nhanh.vn/catalog/product_compare/add/product/1037/uenc/aHR0cDovL25oYW5oLnZuL21heS1sYW0tYmFuaC1uZ28tbmdoaW5oLWhpbmgtdGh1Lmh0bWw,/" class="link-compare">Thêm vào danh sách so sánh</a></p>
    <div class="clear"></div>
</div>


                            <div class="clear">
                        </div>
                    </div>
                        
                    <div id="product-shop-view-detail">
                                        

        
    <div class="price-box">
                                                            <span class="regular-price" id="product-price-4010">
                    <span class="price">580.000&nbsp;₫</span>                </span>
                <span class="VAT-label"> (VAT: +10%)</span>
                        
            
    </div>

        <p class="availability in-stock"><span class="label-attribute">Tình trạng </span><span class="value-attribute">:&nbsp;&nbsp;&nbsp;Còn hàng</span></p>
                 

                    
                                                                            <p><span class="label-attribute">Chất lượng </span><span class="value-attribute">:&nbsp;&nbsp;&nbsp;Mới</span></p>
                                                                                <p><span class="label-attribute">Nguồn hàng </span><span class="value-attribute">:&nbsp;&nbsp;&nbsp;Hàng công ty </span></p>
                                                                                    <p><span class="label-attribute">Vận chuyển </span><span class="value-attribute">:&nbsp;&nbsp;&nbsp;Liên hệ</span></p>
                    
                    
                    
                    
                    
                                                <!--ShortDescription-->
                                                                        <!--End ShortDescription-->

                    <!--
Scroll to thông số kỹ thuật trang chi tiế sản phẩm
-->

<div class="infor-teech"><a class="link-inforteech" href="#" onclick="auto_scroll('.box-additional')"> Thông số kỹ thuật</a> </div>
                <script type="text/javascript">
                    function auto_scroll(anchor) {
                        var target = jQuery(anchor);
                        target = target.length && target || jQuery('[name=' + anchor.slice(1) + ']');
                        if (target.length) {
                            var targetOffset = target.offset().top;
                            jQuery('html,body').animate({scrollTop: targetOffset},10);
                            return false;
                        }
                    }
                </script>                                                    <div class="short-description contact " style="padding-top:20px;padding-bottom: 0px;">                                                        
                                                        <p>
                                                                Hỗ trợ trực tuyến:
                                                                <a href="ymsgr:SendIM?banhang_nhanh"><img src="may_files/yahoo.png"></a>
                                                                <a href="skype:huongntl_nhanh?chat"><img src="may_files/skype.png"></a>
                                                                &nbsp;&nbsp;&nbsp;&nbsp;
                                                               
                                                                &nbsp;&nbsp;&nbsp;&nbsp;
                                                                <img src="may_files/email.gif">&nbsp;
                                                                <span class="email-information">
                                                                Email:<a href="mailto:nhanhhcm@nhanh.vn" class="information">nhanhhcm@nhanh.vn</a></span>
                                                        </p>
                                                                                                                
                                                        <p>
                                                             	<img src="may_files/icon_phone.png" height="13px" width="16px">&nbsp;
                                                                Điện thoại: <span class="information">08.3849.7899 - 08.3849.6863 - Hotline: 0937.863.889 </span>
                                                        </p>
                                                        
                                                        <!--  Load like facebook  -->
                                                        <div>                                                        	
                                                            <div class="facebook-box" style="float:left; height: 30px;margin:0;width: 103px;"><iframe src="may_files/like_002.htm" style="border: medium none; overflow: hidden; width: 120px; height: 21px;" allowtransparency="true" frameborder="0" scrolling="no"></iframe></div>
                                                           <p class="tooltip_facebook" style="margin:0;clear: none;">
                                                                <span class="left">
                                                                <span class="right">Like cấp tốc - Nhận giá Sốc</span>
                                                                </span>
                                                            </p>
                                                            <div class="clear"></div>
							</div>
														
														<!--  +1 google g+  -->
														<p style="margin-bottom: 0px;">
															<span id="plus-one-button"><div style="height: 20px; width: 90px; display: inline-block; text-indent: 0pt; margin: 0pt; padding: 0pt; background: none repeat scroll 0% 0% transparent; border-style: none; float: none; line-height: normal; font-size: 1px; vertical-align: baseline;" id="___plusone_0"><iframe allowtransparency="true" hspace="0" id="I1_1330567830517" marginheight="0" marginwidth="0" name="I1_1330567830517" src="may_files/fastbutton.htm" style="position: static; left: 0pt; top: 0pt; width: 90px; margin: 0px; border-style: none; visibility: visible; height: 20px;" tabindex="-1" vspace="0" title="+1" frameborder="0" scrolling="no" width="100%"></iframe></div></span>
														</p>
														                                                          
                                                         
                                                    </div>                                        

                                                                            <!--option-->
                                                                                <!--end option-->
                                                            <div class="clear"></div>
                                                        </div>

                                                    </div>


                                            </div>
                                            <!--Image-->
<div class="product-img-box">

<p class="product-image">
	<div id="wrap" style="top: 0px; z-index: 9999; position: relative;">
		<a href="images/nsam20.jpg" class="cloud-zoom" id="zoom1" rel="adjustX: 10, adjustY:-51, zoomWidth:500, zoomHeight:500  " style="position: relative; display: block;">
		<img style="display: block;" src="images/thumb/nsam20.jpg">    
		</a>
		<div class="mousetrap" style="background-image: url(&quot;.&quot;); z-index: 999; position: absolute; width: 300px; height: 300px; left: 0px; top: 0px;"></div>
	</div>
	<a class="pre-zoom" href="javascript:void(0);"></a>
	<a class="next-zoom" href="javascript:void(0);"></a>
</p>
<ul style="position: absolute; top: 0px; width: 275px;">
							<!-- lienntt sửa: không hiển thị ảnh small image  -->
							<li style="height: 50px;">
	<a href="http://localhost/tienich_2702/images/thumb/nsam20.jpg" imgfull="http://localhost/tienich_2702/images/nsam20.jpg" class="cloud-zoom-gallery popup cboxElement" rel="productlist" reldes="useZoom: 'zoom1', smallImage: 'http://localhost/tienich_2702/images/thumb/nsam20.jpg' " title=""><img src="http://localhost/tienich_2702/images/thumb/nsam20.jpg" alt="" height="44" width="44"></a>
</li>
								<!-- lienntt sửa: không hiển thị ảnh small image  -->
								<!-- lienntt sửa: không hiển thị ảnh small image  -->
							<li style="height: 50px;">
	<a href="http://localhost/tienich_2702/images/thumb/0379339854875272May-lam-kem-Facare20.jpg" imgfull="http://localhost/tienich_2702/images/thumb/0379339854875272May-lam-kem-Facare20.jpg" class="cloud-zoom-gallery popup cboxElement" rel="productlist" reldes="useZoom: 'zoom1', smallImage: 'http://localhost/tienich_2702/images/thumb/0379339854875272May-lam-kem-Facare20.jpg' " title=""><img src="http://localhost/tienich_2702/images/thumb/0379339854875272May-lam-kem-Facare20.jpg" alt="" height="44" width="44"></a>
</li>
								<!-- lienntt sửa: không hiển thị ảnh small image  -->
							<li style="height: 50px;">
	<a href="http://localhost/tienich_2702/images/thumb/nsam20.jpg" imgfull="http://localhost/tienich_2702/images/nsam20.jpg" class="cloud-zoom-gallery popup cboxElement" rel="productlist" reldes="useZoom: 'zoom1', smallImage: 'http://localhost/tienich_2702/images/thumb/nsam20.jpg' " title=""><img src="http://localhost/tienich_2702/images/thumb/nsam20.jpg" alt="" height="44" width="44"></a>
</li>
								<!-- lienntt sửa: không hiển thị ảnh small image  -->
							<li style="height: 50px;">
	<a href="http://localhost/tienich_2702/images/thumb/nsam20.jpg" imgfull="http://localhost/tienich_2702/images/nsam20.jpg" class="cloud-zoom-gallery popup cboxElement" rel="productlist" reldes="useZoom: 'zoom1', smallImage: 'http://localhost/tienich_2702/images/thumb/nsam20.jpg' " title=""><img src="http://localhost/tienich_2702/images/thumb/nsam20.jpg" alt="" height="44" width="44"></a>
</li>
								<!-- lienntt sửa: không hiển thị ảnh small image  -->
							<li style="height: 50px;">
	<a href="http://localhost/tienich_2702/images/nsam20.jpg" class="cloud-zoom-gallery popup cboxElement" rel="productlist" reldes="useZoom: 'zoom1', smallImage: 'http://localhost/tienich_2702/images/thumb/nsam20.jpg' " title=""><img src="http://localhost/tienich_2702/images/thumb/nsam20.jpg" alt="" height="44" width="44"></a>
</li>
							
<!-- tuantq them anh thumb khi chi co 1 anh -->				        
</ul>
</div>
                    <script type="text/javascript">
                        jQuery(function(){
                            jQuery("div.mor-image-control").carousel({ loop: true , dispItems: 5, animSpeed: 300, nextBtn: '<a href="javascript:void(0);"></a>', prevBtn:'<a href="javascript:void(0);"></a>' });
                            jQuery("a[rel='productlist']").colorbox({slideshow:false});
                        });
                    </script>
                                                        </div>
                                                        <!--End Image-->
                                                        <div class="clearer"></div>

                                                    </form>
                                                    <script type="text/javascript">
                                                        //<![CDATA[
                                                        var productAddToCartForm = new VarienForm('product_addtocart_form');
                                                        productAddToCartForm.submit = function(button, url) {
                                                            if (this.validator.validate()) {
                                                                var form = this.form;
                                                                var oldUrl = form.action;

                                                                if (url) {
                                                                    form.action = url;
                                                                }
                                                                var e = null;
                                                                try {
                                                                    this.form.submit();
                                                                } catch (e) {
                                                                }
                                                                this.form.action = oldUrl;
                                                                if (e) {
                                                                    throw e;
                                                                }

                                                                if (button && button != 'undefined') {
                                                                    button.disabled = true;
                                                                }
                                                            }
                                                        }.bind(productAddToCartForm);

                                                        productAddToCartForm.submitLight = function(button, url){
                                                            if(this.validator) {
                                                                var nv = Validation.methods;
                                                                delete Validation.methods['required-entry'];
                                                                delete Validation.methods['validate-one-required'];
                                                                delete Validation.methods['validate-one-required-by-name'];
                                                                if (this.validator.validate()) {
                                                                    if (url) {
                                                                        this.form.action = url;
                                                                    }
                                                                    this.form.submit();
                                                                }
                                                                Object.extend(Validation.methods, nv);
                                                            }
                                                        }.bind(productAddToCartForm);
                                                        //]]>
                                                    </script>
                                                    </div>
                                                    <!--Detail info-->

                                                            <div class="product-collateral">
                                                                <div class="tab-header-menu">
                        <ul class="tabmenu" style="display:inline">
                            <li class="active">
                                <a href="javascript:void(0);" id="tab-product-detail" class="active">
                                    <span>Chi tiết sản phẩm</span>
                                </a>
                            </li>
                                                    </ul>
                    </div>
                    <div class="line-header"></div>

                    <div class="tab-content" id="content-tab-product-detail" style="clear:both;padding-top: 10px; width:100%;">
                            <div class="std">
        <table style="width: 900px;" align="center" border="0">
<tbody>
<tr>
<td>&nbsp;</td>
<td>
<p><span><em><strong>Chỉ 355.000 để sở hữu máy làm bánh hình thú ngộ nghĩnh chỉ có tại nhanh.vn</strong></em></span></p>
<p><span>Máy làm bánh sử dụng điện năng để nướng chín bánh. Bạn chỉ cần 
đổ bột đã trộn vào trong khuôn và bật máy, trong một thời gian ngắn, máy
 sẽ tạo ra những chiếc bánh&nbsp;nướng thơm ngon và đẹp mắt với nhiều 
khuôn hình đáng yêu như&nbsp;<strong>Bông hoa,</strong>&nbsp;<strong>Mèo kitty, mặt cười, heo con</strong>...&nbsp;cho cả gia đình thưởng thức<br></span></p>
<p><img src="may_files/1_6_52_002.jpg" alt="" height="300" width="300"></p>
<p>&nbsp;</p>
<p><span>Với chiếc máy làm bánh kẹp này, bạn dễ dàng và nhanh chóng thực
 hiện được một bữa sáng bổ dưỡng cho người thân với món bánh kẹp nhân 
thịt hoặc bánh kẹp nhân mứt hoa quả.Bé yêu nhà bạn sẽ rất thích những 
chiếc bánh hình ngộ nghĩnh.</span></p>
<p><span><img src="may_files/rv1696034_1313140560.jpg" alt="" height="300" width="447"></span></p>
<p><span><strong>* Thông số kỹ thuật:</strong></span></p>
<p><span>+ Cân nặng: 1,62kg</span></p>
<p><span>+ Điện áp: 220V</span></p>
<p><span>+ Công suất: 1000W</span></p>
<p><span>+ Kich thước: 324x128x230mm</span></p>
<p><img src="may_files/3_5_40_002.jpg" alt="" height="400" width="400"></p>
<p><span><em><strong><span>Hướng dẫn cách làm bánh:</span></strong></em></span></p>
<p><span><strong>a. Nguyên liệu chuẩn bị</strong></span></p>
<p><span>- 250 gram bột</span></p>
<p><span>- 125 gram đường</span></p>
<p><span>- 1 gói đường vali</span></p>
<p><span>- 2 lòng đỏ trứng gà</span></p>
<p><span>- 125 gram bơ</span></p>
<p><span>- 3 muỗng đường bột (đường mịn như bột)</span></p>
<p><span>- 50 gram Chocolate lỏng (dùng quét lên bánh)</span></p>
<p><span><strong>b. Cách làm</strong></span></p>
<p><span>- Ðánh bơ, trứng gà, đường và đường vali đều với nhau, lưu ý 
đánh đều nhưng đừng đánh sủi bọt lên, sau đó rắc đều bột vào đánh đến 
khi tất cả đã trộn đều.</span></p>
<p><span>- Sau khi đã pha trộn xong hỗn hợp, đổ hỗn hợp vào khuôn máy 
làm bánh (trước khi đổ nên bôi trơn một ít dầu để khi bánh chín lấy ra 
dễ dàng hơn)</span></p>
<p><span>- Cắm điện rồi vặn nút tròn màu vàng về phía bên tay phải, khi 
đó máy sẽ hiện lên 2 đèn xanh và đỏ, khoảng 10 phút sau bánh chín. Lúc 
đó bạn có thể lấy ra và măm măm. Thật nhanh chóng và dễ dàng đúng không?</span></p>
<p><img src="may_files/rv1696033_1313140560.jpg" alt="" height="731" width="568"></p>
<p><span><em><strong>Ưu điểm nổi bật của máy làm bánh:</strong></em></span></p>
<p><span>&nbsp;Hoàn toàn sử dụng điện năng để nướng chín bánh với khay 
nướng chống dính, bạn có thể dễ dàng lấy bánh ra khi bánh chín mà không 
sợ làm vỡ hay nát bánh.</span></p>
<p><span><img src="may_files/558.png" alt="" height="300" width="443"><br></span></p>
<p><span>&nbsp;Máy làm bánh tạo hình thú&nbsp;thực sự là một người bạn 
không thể thiếu của các bà nội trợ, đặc biệt là trong thời hiện đại ngày
 nay, quỹ thời gian eo hẹp, nhịp sống trở nên nhanh hơn thì sản phẩm này
 thực sự là vô cùng cần thiết. Bạn sẽ có một món ăn đầy đủ chất dinh 
dưỡng mà không cần phải chờ lâu hay chế biến phức tạp nữa. Mặt khác, do 
trên thị trường hiện nay có quá nhiều sản phẩm bánh ngọt cũng như bánh 
nướng, mà bạn còn chưa yên tâm về chất lượng thì chiếc máy này sẽ thực 
sự giúp bạn loại bỏ đi nỗi lo lắng đó.</span></p>
<p><span>Bạn còn có thể làm những chiếc bánh hình ngộ nghĩnh này làm món quà sinh nhật bất ngờ cho người ấy nữa đấy.</span></p>
</td>
<td>&nbsp;</td>
</tr>
</tbody>
</table>
<p style="text-align: center;"><span style="color: #800000; font-size: medium;"><strong><em><br></em></strong></span></p>
<div><span style="font-size: medium;"><br></span></div>    </div>
                    </div>
                    
                    <script type="text/javascript">
                        jQuery(function() {
                            jQuery('.all-vendors').click(function(){
                                hideAllMenu();
                                jQuery('#tab-other-vendors').parent().addClass('active');
                                jQuery('#tab-other-vendors').addClass('active');
                                jQuery('#content-tab-other-vendors').show();
                            });
                            jQuery('.tabmenu li a').each(function(){
                                jQuery(this).click(function(event){
                                  event.preventDefault();
                                  hideAllMenu();
                                  jQuery(this).parent().addClass('active');
                                  jQuery(this).addClass('active');
                                  jQuery('#content-'+jQuery(this).attr('id')).show();
                                })
                            });
                            function hideAllMenu(){
                                jQuery('.tabmenu li a').each(function(){
                                    jQuery(this).removeClass('active');
                                    jQuery(this).parent().removeClass('active');
                                    jQuery('#content-'+jQuery(this).attr('id')).hide();
                                })
                            }
                        });
                     </script>
                                                                    <div class="box-collateral box-additional">
                    <h2>Thông số kỹ thuật</h2>
    <table class="data-table" id="product-attribute-specs-table">
        <colgroup><col width="25%">
        <col>
        </colgroup><tbody>
                                <tr class="first odd">
                <th class="label">Tên sản phẩm</th>
                <td class="data last">Máy làm bánh ngộ nghĩnh hình thú </td>
            </tr>
                                                                                    <tr class="even">
                <th class="label">Nguồn hàng</th>
                <td class="data last">Hàng công ty </td>
            </tr>
                                            <tr class="odd">
                <th class="label">Xuất xứ</th>
                <td class="data last">Trung Quốc</td>
            </tr>
                                            <tr class="last even">
                <th class="label">Vận chuyển</th>
                <td class="data last">Liên hệ</td>
            </tr>
                            </tbody>
    </table>
    <script type="text/javascript">decorateTable('product-attribute-specs-table')</script>
                                                                </div>
                       
<div class="box-collateral box-reviews" id="customer-reviews">
        </div>
</div>
<!--End Detail info-->
</div>

<script type="text/javascript">
    Mage.Cookies.set('external_no_cache', 1);
</script>
                </div>
                
    </div>
    </div>

                </div>
            </div>
        </div>
            </div>
</div>