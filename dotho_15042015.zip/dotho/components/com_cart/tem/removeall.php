<?php
	unset($_SESSION["PROIDS"]);
	unset($_SESSION["PROSLS"]);
?>
<script>window.location="<?php echo WEBSITE; ?>viewcart.html"</script>