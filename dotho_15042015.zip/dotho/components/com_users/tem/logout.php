<?php
global $UserLogin;
$UserLogin->LOGOUT();
echo "<script language=\"javascript\">window.location='index.php'</script>";
?>