<address style="font-style:normal;">
	<div style="text-align:center;">
    Copyright © 2008 by trungNguyen All Rights Reserved. Design & Devlopment <strong title="Php Developer">trungNguyen</strong>.<br />
    </div>
</address>

