<fieldset>
        	<legend>Lỗi</legend>
            Tên đăng nhập hoặc mật khẩu chưa đúng. Click vào <a href="index.php?com=login"> đây</a> để đăng nhập lại.
        </fieldset>