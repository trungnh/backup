<fieldset>
        	<legend>Ok</legend>
            Đăng nhập thành công. Click vào <a href="index.php"> đây</a> để quay lai trang chủ
        </fieldset>