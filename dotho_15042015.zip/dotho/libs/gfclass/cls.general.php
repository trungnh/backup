<?php
class CLS_GENERAL extends CLS_MYSQL{
	// properties
	
	function CLS_GENERAL(){
		// contructor function
	}
	function load_language(){
		
	}
	function load_template(){
	}
	function load_content(){
	}
}
?>