<a href="#">Đăng nhập</a>
<div class="login_box">
	<form name="frmlogin" id="frmlogin" action="" method="post">
        <p><label for="username">Tên đăng nhập: </label><input type="text" size="30" name="username" id="username"></p>
        <p><label for="password">Mật khẩu: </label><input type="password" size="30" name="password" id="password"></p>
        <button class="submit" type="submit">ĐĂNG NHẬP</button>
    </form>
</div>