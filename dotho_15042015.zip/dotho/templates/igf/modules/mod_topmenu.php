<ul>
	<li><a href="#">Trang chủ</a>
    	<div class="box_submenu">
        	<div class="intro_submenu">
            	<h2 class="pusher">CLOUD COMPUTING SERVER</h2>
<p>DomainGurus offers REAL Windows Cloud Servers, not a simple VPS. What is the difference?</p>
<p>A VPS is only a virtual machine running on a physical machine; whereas a cloud server is a highly available cloud server instance running on a highly available, fully redundant cluster of servers and SAN components.</p>
            </div>
            <ul class="submenu">
            	<li><a href="#">item 1</a></li>
                <li><a href="#">item 2</a></li>
                <li><a href="#">item 3</a></li>
                <li><a href="#">item 4</a></li>
                <li><a href="#">item 5</a></li>
            </ul>
        </div>
    </li>
    <li><a href="#">Giới thiệu</a>
    	<div class="box_submenu">
        	<div class="intro_submenu">
            	<h2 class="pusher">CLOUD COMPUTING SERVER</h2>
<p>DomainGurus offers REAL Windows Cloud Servers, not a simple VPS. What is the difference?</p>
<p>A VPS is only a virtual machine running on a physical machine; whereas a cloud server is a highly available cloud server instance running on a highly available, fully redundant cluster of servers and SAN components.</p>
            </div>
            <ul class="submenu">
            	<li><a href="#">item 1</a></li>
                <li><a href="#">item 2</a></li>
                <li><a href="#">item 3</a></li>
            </ul>
        </div>
    </li>
    <li><a href="#">Cơ sở hạ tầng</a>
    	<div class="box_submenu">
        	<div class="intro_submenu">
            	<h2 class="pusher">CLOUD COMPUTING SERVER</h2>
<p>DomainGurus offers REAL Windows Cloud Servers, not a simple VPS. What is the difference?</p>
<p>A VPS is only a virtual machine running on a physical machine; whereas a cloud server is a highly available cloud server instance running on a highly available, fully redundant cluster of servers and SAN components.</p>
            </div>
            <ul class="submenu">
            	<li><a href="#">item 1</a></li>
                <li><a href="#">item 2</a></li>
                <li><a href="#">item 3</a></li>
            </ul>
        </div>
    </li>
    <li><a href="#">Dịch vụ</a></li>
    <li><a href="#">Hỗ trợ</a></li>
    <li><a href="#">Liên hệ</a></li>
</ul>