<?php
define("ISN'T EXIST","isn't exist");
?>