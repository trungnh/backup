<?php
	define("PRODUCT_ISNT_EXIST","Product isn't exist");
	define("NEW_PRODUCTS","New products");
?>