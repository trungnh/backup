<?php
	$objmodule=new CLS_MODULE;
	$objmodule->LangID;
	$objmodule->getModByID($rows["mod_id"]);
?>