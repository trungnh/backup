<span class="close_bottom"></span>
<span class="close_buttom close"></span>
<div id="popup_bottom">
<?php
echo uncodeHTML($objmodule->HTML);
?>
</div>
