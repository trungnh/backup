<div class="catalog">
<?php
$objcatalog=new CLS_CATALOG();
echo $objcatalog->listMenuCatalog(" ",0,0);
?>
</div>
<div class="catalog-bottom"></div>